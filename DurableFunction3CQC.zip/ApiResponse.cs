﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurableFunction3CQC
{
    public class ApiResponse
    {
        [JsonProperty("total")]
        public int Total { get; set; }

        [JsonProperty("firstPageUri")]
        public string FirstPageUri { get; set; }

        [JsonProperty("Page")]
        public int Page { get; set; }

        [JsonProperty("PreviousPageUri")]
        public object PreviousPageUri { get; set; }

        [JsonProperty("LastPageUri")]
        public string LastPageUri { get; set; }

        [JsonProperty("NextPageUri")]
        public string NextPageUri { get; set; }

        [JsonProperty("PerPage")]
        public int PerPage { get; set; }

        [JsonProperty("TotalPages")]
        public int TotalPages { get; set; }

        [JsonProperty("locations")]
        public List<Location> Locations { get; set; }
    }

    public class Location
    {
        [JsonProperty("locationId")]
        public string LocationId { get; set; }

        [JsonProperty("locationName")]
        public string LocationName { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }
    }
}
