using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;

namespace DurableFunction3CQC
{
    public static class Function3
    {

        private static readonly HttpClient httpClient = new HttpClient();
        private static string ApiUrl = "https://api.service.cqc.org.uk/public/v1/locations?perPage=10";

        [Function(nameof(Function3))]
        //public static async Task<List<string>> RunOrchestrator(
        //    [OrchestrationTrigger] TaskOrchestrationContext context)
        public static async Task<List<Location>> RunOrchestrator(
            [OrchestrationTrigger] TaskOrchestrationContext context)
        {
            ILogger logger = context.CreateReplaySafeLogger(nameof(Function3));
            logger.LogInformation("Saying hello.");
            var outputs = new List<string>();

            // Replace name and input with values relevant for your Durable Functions Activity
            //outputs.Add(await context.CallActivityAsync<string>(nameof(SayHello3), "Tokyo"));
            //outputs.Add(await context.CallActivityAsync<string>(nameof(SayHello3), "Seattle"));
            //outputs.Add(await context.CallActivityAsync<string>(nameof(SayHello3), "London"));

            var locations = await context.CallActivityAsync<List<Location>>("GetLocationsActivity", null);

            // returns ["Hello Tokyo!", "Hello Seattle!", "Hello London!"]
            //return outputs;
            return locations;
        }

        [Function(nameof(SayHello3))]
        public static string SayHello3([ActivityTrigger] string name, FunctionContext executionContext)
        {
            ILogger logger = executionContext.GetLogger("SayHello3");
            logger.LogInformation("Saying hello to {name}.", name);
            return $"Hello {name}!";
        }

        [Function("GetLocationsActivity_Function3")]
        //public static async Task<List<Location>> GetLocationsActivity_Function3([ActivityTrigger] string name, FunctionContext executionContext)
        public static async Task<ApiResponse> GetLocationsActivity_Function3([ActivityTrigger] string name, FunctionContext executionContext)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, ApiUrl);
            request.Headers.Add("Ocp-Apim-Subscription-Key", "7394d5e20ca249ec976a8dca142fe041");

            var response = await httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonConvert.DeserializeObject<ApiResponse>(jsonResponse);

            return apiResponse; //apiResponse.Locations;
        }

        [Function("TerminateInstance")]
        public static Task TerminateInstance(
            [DurableClient] DurableTaskClient client,
            [QueueTrigger("terminate-queue")] string instanceId)
        {
            string reason = "Found a bug";
            return client.TerminateInstanceAsync(instanceId, reason);
        }

        [Function("Function3_HttpStart")]
        public static async Task<HttpResponseData> HttpStart(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req,
            [DurableClient] DurableTaskClient client,
            FunctionContext executionContext)
        {
            ILogger logger = executionContext.GetLogger("Function3_HttpStart");

            // Function input comes from the request content.
            string instanceId = await client.ScheduleNewOrchestrationInstanceAsync(nameof(Function3));

            logger.LogInformation("Started orchestration with ID = '{instanceId}'.", instanceId);

            // Returns an HTTP 202 response with an instance management payload.
            // See https://learn.microsoft.com/azure/azure-functions/durable/durable-functions-http-api#start-orchestration
            return await client.CreateCheckStatusResponseAsync(req, instanceId);
        }
    }
}
